# Project3 Custom Shell

Student Name: Peiyuan Li

CS Login: pli

Email: pli233@wisc.edu

Status of your implementation:  Finish all job and passed every provided test.

Description of resources used in the creation of my solution:

1. Youtube: I watched some online video to get familiar with the project

   a) https://www.youtube.com/@CodeVault

   b) https://www.youtube.com/watch?v=l6-663i8bwQ&t=214s&ab_channel=cs631apue

2. Linux man page: https://linux.die.net/man/

   I use this website to get familiar to some command/function

3. Stackoverflow: i used it to find out some problem about my job control.